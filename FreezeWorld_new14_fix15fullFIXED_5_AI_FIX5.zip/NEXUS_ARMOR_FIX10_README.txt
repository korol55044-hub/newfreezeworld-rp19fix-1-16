FreezeWorld_new14_fix10full — Nexus worn armor wiring (Minecraft Java 1.21.11)

CMD / inventory model mapping:
  NETHERITE_HELMET      CMD 66401 -> Nexus Helmet icon/model
  NETHERITE_CHESTPLATE  CMD 66402 -> Nexus Chestplate icon/model
  NETHERITE_LEGGINGS    CMD 66403 -> Nexus Leggings icon/model
  NETHERITE_BOOTS       CMD 66404 -> Nexus Boots icon/model

WORN ARMOR (Vanilla 1.21.11):
The resource pack contains the selective equipment asset:
  nexusset:nexus_armor

For the Nexus texture to render ON THE PLAYER, the Nexus item itself must also carry:
  minecraft:equippable.asset_id = "nexusset:nexus_armor"

This is intentionally item-side. Do NOT replace minecraft:netherite equipment globally.
Therefore ordinary netherite armor keeps the normal vanilla worn texture.

Exact 1.21.11 test commands:
/give @p minecraft:netherite_helmet[minecraft:custom_model_data={floats:[66401]},minecraft:equippable={slot:"head",asset_id:"nexusset:nexus_armor"}] 1
/give @p minecraft:netherite_chestplate[minecraft:custom_model_data={floats:[66402]},minecraft:equippable={slot:"chest",asset_id:"nexusset:nexus_armor"}] 1
/give @p minecraft:netherite_leggings[minecraft:custom_model_data={floats:[66403]},minecraft:equippable={slot:"legs",asset_id:"nexusset:nexus_armor"}] 1
/give @p minecraft:netherite_boots[minecraft:custom_model_data={floats:[66404]},minecraft:equippable={slot:"feet",asset_id:"nexusset:nexus_armor"}] 1

Control test (must remain vanilla when worn):
/give @p minecraft:netherite_helmet 1
/give @p minecraft:netherite_chestplate 1
/give @p minecraft:netherite_leggings 1
/give @p minecraft:netherite_boots 1

Important: a resource pack can define the equipment asset, but it cannot add/change item components on server items. If a custom-item plugin creates the Nexus armor with CMD only, add the equippable asset_id above in that item/plugin configuration.
